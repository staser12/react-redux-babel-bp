import React from 'react';

class NewComponent extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>This is a new component --- 2!</div>
    );
  }
}

export default NewComponent;